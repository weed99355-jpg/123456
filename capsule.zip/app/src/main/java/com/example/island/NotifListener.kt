package com.example.island

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {
    private val seen = HashMap<String, Int>()
    private var callKey: String? = null

    override fun onListenerConnected() {
        IslandService.instance?.refreshMedia()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val island = IslandService.instance ?: return
        val n = sbn.notification
        val isCall = n.category == Notification.CATEGORY_CALL
        if (!isCall) {
            if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
            if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
            when (n.category) {
                Notification.CATEGORY_TRANSPORT,
                Notification.CATEGORY_PROGRESS,
                Notification.CATEGORY_SERVICE,
                Notification.CATEGORY_SYSTEM -> return
            }
        }
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (ex.getCharSequence(Notification.EXTRA_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString() ?: ""
        if (title.isEmpty() && text.isEmpty()) return
        val hash = (title + "|" + text).hashCode()
        if (seen[sbn.key] == hash) return
        seen[sbn.key] = hash
        val icon = try {
            n.getLargeIcon()?.loadDrawable(this) ?: n.smallIcon?.loadDrawable(this)
        } catch (e: Exception) {
            null
        }
        val info = Info(icon, title.ifEmpty { text }, if (title.isEmpty()) "" else text, n.contentIntent)
        if (isCall) {
            callKey = sbn.key
            island.onCall(info)
        } else {
            island.onNotification(info)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        seen.remove(sbn.key)
        if (sbn.key == callKey) {
            callKey = null
            IslandService.instance?.onCall(null)
        }
    }
}
